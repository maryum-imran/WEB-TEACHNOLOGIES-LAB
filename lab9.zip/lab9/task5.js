const http = require('http');

const server = http.createServer((req, res) => {
    if (req.url === '/api') {
        res.writeHead(200, { 'Content-Type': 'application/json' });
        const student = {
            name: "maryam",
            course: "ADCS"
        };
        res.end(JSON.stringify(student));
    } else {
        res.write("Invalid route");
        res.end();
    }
});

server.listen(3212, () => {
    console.log("API running at http://localhost:3212/api");
});