console.log("Name: maryam");
console.log("Course: ADCS");
console.log("University: AIR University");