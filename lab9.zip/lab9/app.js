const math = require('./math');

console.log("Subtraction: " + math.subtract(10, 4));
console.log("Multiplication: " + math.multiply(6, 5));