const fs = require('fs');
fs.writeFileSync('student.txt', 'Name: Maryam\nCourse: ADCS\nUniversity: AIR University');
const data = fs.readFileSync('student.txt', 'utf8');
console.log(data);